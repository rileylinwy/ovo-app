// --- 数据库与全局状态 (js/db.js) ---

// 常量定义
const BLOCKED_API_DOMAINS = [
    'api522.pro',
    'api521.pro',
    'api520.pro'
];

const colorThemes = {
    'white_pink': {
        name: '白/粉',
        received: {bg: 'rgba(255,255,255,0.9)', text: '#6D6D6D'},
        sent: {bg: 'rgba(255,204,204,0.9)', text: '#A56767'}
    },
    'white_blue': {
        name: '白/蓝',
        received: {bg: 'rgba(255,255,255,0.9)', text: '#6D6D6D'},
        sent: {bg: 'rgba(173,216,230,0.9)', text: '#4A6F8A'}
    },
    'white_yellow': {
        name: '白/黄',
        received: {bg: 'rgba(255,255,255,0.9)', text: '#6D6D6D'},
        sent: {bg: 'rgba(249,237,105,0.9)', text: '#8B7E4B'}
    },
    'white_green': {
        name: '白/绿',
        received: {bg: 'rgba(255,255,255,0.9)', text: '#6D6D6D'},
        sent: {bg: 'rgba(188,238,188,0.9)', text: '#4F784F'}
    },
    'white_purple': {
        name: '白/紫',
        received: {bg: 'rgba(255,255,255,0.9)', text: '#6D6D6D'},
        sent: {bg: 'rgba(185,190,240,0.9)', text: '#6C5B7B'}
    },
    'black_red': {
        name: '黑/红',
        received: {bg: 'rgba(30,30,30,0.85)', text: '#E0E0E0'},
        sent: {bg: 'rgb(226,62,87,0.9)', text: '#fff'}
    },
    'black_green': {
        name: '黑/绿',
        received: {bg: 'rgba(30,30,30,0.85)', text: '#E0E0E0'},
        sent: {bg: 'rgba(119,221,119,0.9)', text: '#2E5C2E'}
    },
    'black_white': {
        name: '黑/白',
        received: {bg: 'rgba(30,30,30,0.85)', text: '#E0E0E0'},
        sent: {bg: 'rgba(245,245,245,0.9)', text: '#333'}
    },
    'white_black': {
        name: '白/黑',
        received: {bg: 'rgba(255,255,255,0.9)', text: '#6D6D6D'},
        sent: {bg: 'rgba(50,50,50,0.85)', text: '#F5F5F5'}
    },
    'yellow_purple': {
        name: '黄/紫',
        received: {bg: 'rgba(255,250,205,0.9)', text: '#8B7E4B'},
        sent: {bg: 'rgba(185,190,240,0.9)', text: '#6C5B7B'}
    },
    'pink_blue': {
        name: '粉/蓝',
        received: {bg: 'rgba(255,231,240,0.9)', text: '#7C6770'},
        sent: {bg: 'rgba(173,216,230,0.9)', text: '#4A6F8A'}
    },
};

const defaultWidgetSettings = {
    centralCircleImage: 'https://i.postimg.cc/mD83gR29/avatar-1.jpg',
    topLeft: { emoji: '🎧', text: '𝑀𝑒𝑚𝑜𝑟𝑖𝑒𝑠✞' },
    topRight: { emoji: '🐈‍⬛', text: '𐙚 ♰.𝐾𝑖𝑡𝑡𝑒𝑛.♰' },
    bottomLeft: { emoji: '💿', text: '᪗₊𝔹𝕒𝕓𝕖𝕚𝕤₊' },
    bottomRight: { emoji: '🥛', text: '.☘︎ ˖+×+.' }
};

const defaultIcons = {
    'chat-list-screen': {name: '404', url: 'https://i.postimg.cc/VvQB8dQT/chan-143.png'},
    'api-settings-screen': {name: 'api', url: 'https://i.postimg.cc/mr45mv5b/png-(103).png'},
    'wallpaper-screen': {name: '壁纸', url: 'https://i.postimg.cc/3wqFttL3/chan-90.png'},
    'world-book-screen': {name: '世界书', url: 'https://i.postimg.cc/prCWkrKT/chan-74.png'},
    'customize-screen': {name: '自定义', url: 'https://i.postimg.cc/vZVdC7gt/chan-133.png'},
    'font-settings-screen': {name: '字体', url: 'https://i.postimg.cc/FzVtC0x4/chan-21.png'},
    'tutorial-screen': {name: '教程', url: 'https://i.postimg.cc/6QgNzCFf/chan-118.png'},
    'day-mode-btn': {name: '白昼模式', url: 'https://i.postimg.cc/Jz0tYqnT/chan-145.png'},
    'night-mode-btn': {name: '夜间模式', url: 'https://i.postimg.cc/htYvkdQK/chan-146.png'},
    'forum-screen': {name: '论坛', url: 'https://i.postimg.cc/fyPVBZf1/1758451183605.png'},
    'music-screen': {name: '音乐', url: 'https://i.postimg.cc/ydd65txK/1758451018266.png'},
    'diary-screen': {name: '日记本', url: 'https://i.postimg.cc/bJBLzmFH/chan-70.png'},
    'piggy-bank-screen': {name: '存钱罐', url: 'https://i.postimg.cc/3RmWRRtS/chan-18.png'},
    'pomodoro-screen': {name: '番茄钟', url: 'https://i.postimg.cc/PrYGRDPF/chan-76.png'},
    'storage-analysis-screen': {name: '存储分析', url: 'https://i.postimg.cc/J0F3Lt0T/chan-107.png'},
    'magic-room-screen': {name: '魔法屋', url: 'https://i.postimg.cc/hPCcZG3v/png-(143).png'},
    'appearance-settings-screen': {name: '外观设置', url: 'https://i.postimg.cc/KcgT1wzQ/DF424409FC54EDFF74D78ECB1311E1D7.png'},
    'theater-screen': {name: '小剧场', url: 'https://i.postimg.cc/t4gXjG8P/7632D362A35EC703E7A81F6FF0F8AE34.png'},
    'biekan-app': {name: 'MCP', url: 'https://i.postimg.cc/5y6G7fn4/5A615115038157EA857BB5D4D8E54EC7.png'}
};

const peekScreenApps = {
    'messages': { name: '消息', url: 'https://i.postimg.cc/Kvs4tDh5/export202509181826424260.png' },
    'memos': { name: '备忘录', url: 'https://i.postimg.cc/JzD0xH1C/export202509181829064550.png' },
    'cart': { name: '购物车', url: 'https://i.postimg.cc/pLwT6VTh/export202509181830143960.png' },
    'transfer': { name: '中转站', url: 'https://i.postimg.cc/63wQBHCB/export202509181831140230.png' },
    'browser': { name: '浏览器', url: 'https://i.postimg.cc/SKcsF02Z/export202509181830445980.png' },
    'drafts': { name: '草稿箱', url: 'https://i.postimg.cc/ZKqC9D2R/export202509181827225860.png' },
    'album': { name: '相册', url: 'https://i.postimg.cc/qBcdpqNc/export202509221549335970.png' },
    'steps': { name: '步数', url: 'https://i.postimg.cc/5NndFrq6/export202509181824532800.png' },
    'unlock': { name: 'unlock！', url: 'https://i.postimg.cc/28zNyYWs/export202509221542593320.png' },
    'wallet': { name: '钱包', url: 'https://i.postimg.cc/NjRxBZXV/20260228-062729.webp' },
    'timeThoughts': { name: '时光想说', url: 'https://i.postimg.cc/FRpWm8MK/20260228-062619.webp' }
};

const DEFAULT_COT_PRESETS = [
    {
        id: 'default',
        name: '默认思维链',
        items: [
            {
                id: 'cot_item_1',
                name: '引子',
                content: '[System Directive]:\n你必须严格遵守 [incipere] 协议。在回复前，请先进入 <thinking> 标签进行深度推演。\n请按以下步骤查阅 System Prompt 中的模块并思考：',
                enabled: true
            },
            {
                id: 'cot_item_2',
                name: '准备动脑了吗？',
                content: '---\n## 【前置规则】\n### **必须**读取所有<logic_rules>和<output_formats>：了解**所有**需要遵守的规则，然后进行以下步骤精简准确的思考',
                enabled: true
            },
            {
                id: 'cot_item_3',
                name: '给我读设定！',
                content: '---\n## 【行为校准】\n基于<char_settings>和<角色活人运转>构建角色人格\n### Phase1: person\n1. **自我意识校验 (Ref: <char_settings>和<角色活人运转>)**\n   - 是否塑造鲜活真实人格？\n   - 你（角色）是否具有自己的聊天习惯/风格？\n   - 你想如何回应我？',
                enabled: true
            },
            {
                id: 'cot_item_4',
                name: '当个人吧。',
                content: '### Phase2: Verisimilitude\n2.**真实聊天**\n   - 是否根据以下两点要求采用了真人聊天思路？\n    - 正常人的注意力是有限的，不会每句话都非得逐句回复。\n    - 不对已有信息进行重复反问。\n    - 断点处理：若与上一条消息间隔较久，默认双方只是自然忙碌后重新拿起手机或默认期间以其他方式保持联系，自然接续话题。',
                enabled: true
            },
            {
                id: 'cot_item_5',
                name: '有特殊格式吗？',
                content: '### Phase3: chat role\n3. **逻辑检索 (Ref: <logic_rules>)**\n   - 当前是否为双语对话情境？若无，跳过此条\n   - 是否需要输出状态栏？若无相关要求，则跳过此条',
                enabled: true
            },
            {
                id: 'cot_item_6',
                name: '最后确认一下。',
                content: '## 【最后确认】\n\n4. 整合<Chatting Guidelines>，是否合理自然回复且不偏离人设？回顾<output_formats>，输出消息格式是否正确？',
                enabled: true
            },
            {
                id: 'cot_item_7',
                name: '尾声',
                content: '每轮输出前，必须先严格按照<thinking>…</thinking>内的步骤进行逐条思考，无需重复其中的条目，但思考内容需精简准确、清晰、可执行，不得跳步骤。\n<thinking>中的所有分析必须在输出中完全落实，不得偏离、删减或弱化。\n\n格式：\n<thinking>\n...思考过程...\n</thinking>',
                enabled: true
            }
        ]
    }
];

const globalSettingKeys = [
    'apiSettings', 'summaryApiSettings', 'backgroundApiSettings', 'supplementPersonaApiSettings', 'peekApiSettings', 'vectorApiSettings', 'apiNodes', 'apiNodeRoutes', 'imageRecognitionEnabled', 'imageRecognitionApiSettings', 'stickerRecognitionApiSettings', 'wallpaper', 'globalChatWallpaper', 'globalCallWallpaper', 'homeScreenMode', 'fontUrl', 'localFontName', 'customIcons', 'customAppNames', 'namePresets',
    'apiPresets', 'summaryApiPresets', 'backgroundApiPresets', 'supplementPersonaApiPresets', 'peekApiPresets', 'vectorApiPresets', 'imageRecognitionApiPresets', 'stickerRecognitionApiPresets', 'bubbleCssPresets', 'chatAppearancePresets', 'myPersonaPresets', 'globalCss',
    'globalCssPresets', 'fontPresets', 'homeSignature', 'forumPosts', 'forumBindings', 'forumUserProfile', 'forumSettings', 'forumApiSettings', 'forumMessages', 'forumStrangerProfiles', 'forumFriendRequests', 'forumPendingRequestFromUser', 'forumAltAccounts', 'forumActiveAccountId', 'forumAccountStates', 'forumRelationships', 'forumKnowledge', 'forumSocialEdges', 'forumStoryThreads', 'forumEvents', 'forumNotifications', 'forumDrafts', 'forumSchemaVersion', 'pomodoroTasks', 'pomodoroSettings', 'pomodoroRecords', 'pomodoroActiveSession', 'insWidgetSettings', 'homeWidgetSettings',
    'chatFolders', 'moments', 'fontSizeScale', 'activePersonaId', 'moreProfileCardBg', 'statusBarPresets', 'regexFilterPresets', 'themeSettings', 'themePresets', 'savedKeyboardHeight',
    'globalSendSound', 'globalReceiveSound', 'globalMessageSentSound', 'globalIncomingCallSound', 'multiMsgSoundEnabled', 'soundPresets', 'galleryPresets', 'iconPresets', 'homeWidgetPresets', 'widgetWallpaperPresets', 'voicePresets', 'fontBuffer',
    'cotSettings', 'cotPresets', 'hasSeenVideoCallDisclaimer', 'hasSeenVideoCallAvatarHint',
    'favorites', 'piggyBank',
    'theaterScenarios', 'theaterPromptPresets',
    'theaterHtmlScenarios', 'theaterHtmlPromptPresets', 'theaterMode',
    'theaterApiSettings', 'theaterFontSize', 'theaterFontPreset',
    'novelAiSettings', 'novelAiPresets', 'novelAiStudioWorks', 'gptImageSettings', 'gptImagePresets',
    'googleImageSettings', 'stabilityImageSettings', 'activeImageProvider',
    'imageAtmosphereGroups', 'activeImageAtmosphereId', 'novelAiVibeSettings', 'novelAiPreciseReferenceSettings',
    'avatarRecognitionDetailLevel', 'autoCompressImage', 'imageGenTimeout',
    'phoneControlRecycleBin', 'nodeTemplates', 'nodeSummaryText', 'memoryTableTemplates', 'vectorMemoryTemplates',
    'nightModeSettings', 'homeStatusBarSettings', 'homeLayoutMode', 'freeHomeLayout', 'freeHomeWidgetPresets', 'stickerCategories', 'magicRoom',
    'keepAliveCodeEnabled', 'keepAliveAutoWakeEnabled', 'keepAliveAudioEnabled', 'keepAliveAudioSrc', 'keepAliveAudioName', 'keepAliveAudioLibrary',
    'ttsPresets', 'weatherApiSettings', 'bilingualSettings', 'bilingualTranslations', 'statusStorageSettings'
];
if (typeof window !== 'undefined') window.globalSettingKeysForBackup = globalSettingKeys;

const appVersion = "6.9.5";
const updateLog = [
    {
        version: "6.9.5",
        date: "2026-10-02",
        revision: "2026-10-02.2",
        notes: [
            "新增角色 API 绑定。不同角色可使用不同接口和模型，也可分别指定聊天、动态、总结、日记、通话等功能使用的 API；支持批量分配、单独调整参数和设置备用接口。",
            "新增群聊成员独立回复。成员可分别使用自己的 API，支持自然发言、全员回复或指定成员，以及依次回复、并行回复和额外接话。可查看成员生成状态，单独停止或重试失败的回复。",
            "新增 API 调用详情。部分聊天消息可通过长按查看实际使用的接口、模型、配置来源及是否启用了备用接口，方便排查问题。",
            "优化动态设置。全局设置、角色设置、人脉设置分别管理。发动态、Story、观看、浏览、点赞、评论和接话可独立控制，回复等待时间和互相接话轮数可分别调整。",
            "完善动态自动观看和提醒。发布后自动为符合可见范围、允许观看的角色和人脉安排观看；提醒会立即安排观看，避免同一次发布重复触发。观看详情可查看等待、处理中、不回应、被设置拦截或失败等状态。",
            "新增“聊天关联动态”开关。可全局设置，也可为单个角色覆盖。关闭后，聊天不再自动带入动态能力、已看内容和互动记录；动态仍可参考聊天与共同记忆，已有数据保留。",
            "优化动态的人设与关系上下文。互动时结合对应用户身份、角色设定、关系、记忆和世界书；人脉使用自己的设定与经历，避免带入所属角色的私聊内容。修复动态修改、删除或可见范围变化后，旧请求仍可能写入结果的问题。",
            "重做 Token 统计逻辑。按实际准备发送的上下文统计，细分人设、世界书、聊天历史、记忆、工具等来源。修正部分节点切换、摘要和世界书绑定情况下的统计偏差，完善接口返回的实际输入、输出、缓存和思考用量展示。",
            "新增 Token 检测与诊断工具。支持检测重复绑定、撤销纠正、复制脱敏诊断和模拟不同历史条数的用量；已适配的 Claude、Gemini 接口可使用官方预计算。设置保存后，统计会同步更新。",
            "新增状态栏模板保存与手动整理。新消息可选择完整保存、精简保存或共享模板；旧数据可筛选会话和模板、预览整理范围、导出恢复备份，并按需恢复。状态栏历史数量改为提醒阈值，超出后不再自动删除。",
            "修复状态栏清理与保存问题。修复清理后旧模板可能被后续保存写回、结果显示不准确、列表和占用未及时更新的问题；完善数据库回读核验、失败处理与局部恢复。",
            "修复并完善 NovelAI 生图。调整不同模型的参数、质量与负面预设、角色坐标及精确参考参数，完善自定义地址、普通／流式生成和多图返回解析。新增 NovelAI 创作工具，支持文生图、图生图、局部重绘、增强、独立放大和漫画创作，并可查看实际发送参数、保存和下载作品。",
            "新增 ElevenLabs 语音合成。角色与用户可分别配置，支持读取账号音色和模型、填写 Voice ID、自定义接口地址及试听。补充 MiniMax 国内／国际地址，Group ID 改为可选，保留旧配置兼容。",
            "修复语音播放与下载问题。修复用户语音受到角色语音开关影响、停止后仍可能开始播放、旧队列干扰新播放等问题；切换语音服务时分别保存音色和语速，避免覆盖原配置。",
            "完善桌面与小组件预设分享。导出时可选择是否包含壁纸、图标、照片和头像等图片，默认不分享；修复导入不含图片的方案时覆盖本机图片的问题。",
            "修复世界书选择与反馈中心细节。修复线下模式明确取消全部世界书后仍沿用原绑定的问题。反馈中心新增自己的消息修改、撤回和删除、文字草稿保存、信箱凭证导入导出，以及处理结果和常见解答展示。",
            "修复动态评论反复接话问题。修复角色与 NPC 持续互相回复、重复评论的问题。互相接话默认关闭，可自行设置轮数；首次评论和回复用户评论不消耗互相接话轮数。更新后会停止旧的自动接话任务，保留已有评论和用户评论回复。",
            "调整动态自主发布机制。取消独立定时发动态，改为跟随正常聊天和已开启的后台消息，由 AI 判断是否发布。新增“后台自主发布动态”开关，控制后台动态及 Story 发布；人脉活动跟随所属角色的聊天和后台消息。修复关闭发布权限后，生成中的旧请求仍可能发布的问题。",
            "修复并完善番茄钟功能。修复后台切换导致计时不准、刷新后进度丢失及正计时结算问题。新增快速开始、任务编辑、专注记录与统计、休息及连续专注、多种角色陪伴方式，支持保存专注成果图片。陪伴回应失败时，计时和记录仍可正常运行。"
        ]
    },
    {
        version: "6.9.4",
        date: "2026-09-30",
        notes: [
            "新增与完善",
            "动态支持批量生成人脉：可按所属角色分组，逐人指定性别、关系和补充要求；生成后可检查、修改、重生成或补齐缺少的人脉，再选择要保存的结果。头像、背景和扩展设定可按需开启。",
            "人脉可关联世界书：生成时可参考选中的内容，并选择随分类更新或锁定当前条目，方便保持人物设定一致。",
            "新增动态网名：角色、人脉和当前用户身份可分别设置只在动态中显示的名字；可控制角色是否感知网名、是否允许自主改名，并为具体角色或人脉单独设置。",
            "动态评论支持编辑和删除。修改自己的评论后，可让角色按新内容重新回复；修改前的回复可在记录中查看。",
            "双语模式扩展到动态、查手机、角色日记、论坛小号、电量心声、番茄钟、小剧场和好友申请。可指定角色常用语言，并选择点击查看译文或默认同时显示；译文会缓存。",
            "————",
            "修复与优化",
            "修复修改动态评论后，生成中的旧回复仍可能按修改前内容写入的问题。",
            "修复群聊双语气泡可能影响未指定成员的问题。",
            "修复重命名世界书分类后，已绑定该分类的人脉可能失去关联的问题。",
            "群聊拍一拍入口移至聊天拓展，避免占用聊天顶栏空间。"
        ]
    },
    {
        version: "6.9.3",
        date: "2026-09-28",
        notes: [
            "共同更新｜反馈中心试用",
            "新增私密反馈和公开反馈入口，可提交功能建议、反馈报错并附上截图。公开反馈经审核通过后展示；作者回复后，可回到投稿时使用的浏览器查看并继续交流。",
            "使用提示：投稿需要联网完成安全验证。中国大陆网络下，验证可能无法加载，暂时无法保证投稿稳定可用。遇到问题可稍后重试，或继续使用原有反馈渠道。反馈记录保存在当前浏览器，请勿清除站点数据。",
            "————",
            "9.28 更新",
            "新增动态功能：可发布动态和 24 小时 Story，添加图片、视频、音频或表情包，设置可见范围，并进行点赞、评论。角色的自主发布、浏览、互动及人脉功能可在设置中开启。",
            "聊天设置新增“显示调试内容”开关，方便查看和排查对话中的隐藏内容。",
            "修复 MCP 活动卡片的样式问题。",
            "存储页面新增“重新检测旧数据”按钮，可扫描历史聊天数据、查看占用来源，并清理检测到的重复图片副本。",
            "拍一拍新增触发方式选择：隐藏头像时可连点聊天标题；群聊顶栏新增“拍”按钮，可选择成员。",
            "私聊日记和群聊总结新增排序选项，可将最新生成的内容排在前面。",
            "优化表情包消息传给 AI 时的重复描述问题，帮助角色更准确地理解表情包。",
            "论坛支持删除其他人发布的可见帖子，可单篇删除，也可多选或全选清理。",
            "状态栏历史记录新增本地保留条数设置，可自定义数量或选择不限条数。"
        ]
    },
    {
        version: "6.9.2",
        date: "2026-09-27",
        notes: [
            "美化设置支持保存为预设，并应用到当前、指定或全部角色。（此前已加入）",
            "修复当前聊天页面打开时，窗口失焦或切到后台后，新消息未及时显示的问题。",
            "优化 Token 统计：图片数据不再计入文字 Token 估算；新增带入消息数、图片数及上次实际用量展示（接口返回用量时）。",
            "优化本地存储：可按会话查看占用，并自动整理旧消息中重复保存的图片数据；完善图片压缩和存储页控制台。",
            "修复角色“查手机”钱包数据清空不彻底的问题。清空时可选择同时删除该角色的真实商城订单；已消费金额不会退回，聊天中的订单消息会保留。",
            "新增“翻译气泡自动展开”开关，私聊和群聊可分别设置。",
            "修复 MCP 活动卡片删除后重新出现、状态和详情更新不完整的问题；同步到聊天改为手动勾选。",
            "改进部分接口的思维链提取与标签补全，尝试解决思维链不显示的问题；仍需在更多模型上验证。"
        ]
    },
    {
        version: "6.9.1",
        date: "2026-09-23",
        notes: [
            "修复偶尔卡在“输入中”的问题。",
            "修复私聊中表情包显示不正确的问题。",
            "修复刷新后未返回首页的问题。",
            "新增“清除聊天 CSS”功能。",
            "新增自由模式和自定义小组件，使用方式更灵活。"
        ]
    },
    {
        version: "6.9.0",
        date: "2026-09-18",
        notes: [
            "9.18 本次更新：",
            "1. 新增 MCP 功能：",
            "- 新增 MCP 功能入口及连接管理。",
            "- 支持配置、连接及使用外部 MCP 服务。",
            "- 优化 MCP 与当前聊天功能的兼容。",
            "2. 去除原登录系统，打开后可以直接进入使用。",
            "3. 优化自动总结：",
            "- 修复部分自动总结无法正常执行的问题。",
            "- 新增总结可视化，可以更加直观地查看总结内容及处理情况。",
            "4. 优化大量数据情况下的运行表现，减少聊天记录、记忆等数据较多时出现明显卡顿的问题。",
            "5. 全面优化生图及语音相关接口：",
            "- 修复 NovelAI 生图自定义地址无法正常使用的问题。",
            "- 修复 GPT 生图相关问题。",
            "- 新增 Gemini 生图。",
            "- 新增火山引擎语音。",
            "- 修复 NM 语音相关问题。",
            "- 优化不同图片 API 的参数与调用兼容。",
            "6. 优化向量记忆：",
            "- 修复部分向量记忆异常。",
            "- 优化向量记忆存储、读取及处理。",
            "- 提升大量记忆情况下的稳定性。",
            "7. 修复语音及视频通话：",
            "- 优化当前语音通话。",
            "- 优化视频通话。",
            "- 修复通话过程中出现空回复时无法正确报错或继续处理的问题。",
            "- 优化通话回复的稳定性。",
            "8. 优化当前 API 与思维链兼容：",
            "- 改进不同 API 返回格式的处理。",
            "- 优化流式与非流式回复。",
            "- 减少思维链内容影响正常回复解析的问题。",
            "9. 优化头像识别系统，提高头像识别、绑定及相关数据处理的稳定性。",
            "10. 优化论坛：",
            "- 调整部分论坛功能逻辑。",
            "- 优化帖子、账号、私信及 AI 互动相关处理。",
            "- 修复部分论坛场景下的异常。",
            "11. 优化 iOS 27 系统下的模糊及显示问题，同时进一步处理 iOS 安全区适配。",
            "12. 优化后台保活：",
            "- 修复部分切换后台后任务容易中断的问题。",
            "- 新增内置静音音频保活方式。",
            "- 优化页面恢复后的状态处理。",
            "13. 尝试修复部分接口出现的 400 请求错误，尤其针对部分特殊 API / 克隆接口的兼容情况进行了调整。",
            "14. 优化自定义提示词：",
            "- 新增更加清晰的提示词管理方式。",
            "- 优化提示词分层。",
            "- 分层设计灵感来源于 **1900老师**，感谢分享与授权。",
            "15. 优化并修复亲属卡相关功能。",
            "16. 优化后台消息：",
            "- 改进应用处于后台时的消息处理。",
            "- 优化恢复页面后的消息状态及回复衔接。",
            "17. 尝试修复「错轮」问题：",
            "- 新增最新轮次保护。",
            "- API 设置中增加对应开关。",
            "- 如果仍然遇到回复对应错误轮次的问题，可以尝试开启该功能。",
            "18. 新增「追加回复」：",
            "- 可以在当前回复基础上继续让角色补充内容。",
            "- 不需要重新发送一条新的用户消息。",
            "19. 新增「拍一拍」互动功能。",
            "20. 优化聊天回复稳定性，增加部分异常回复恢复及保护逻辑，减少 API 返回异常时直接影响当前聊天的问题。",
            "21. 优化自定义提示词相关功能及提示词工作室逻辑，让不同用途的提示词更加容易管理。",
            "22. 优化部分选择框及移动端操作体验，减少不同设备上的原生控件显示差异。",
            "————",
            "本次对聊天、API、生图、记忆和后台运行都进行了较多调整。如果更新后遇到特殊 API 无法使用、回复错轮或后台回复异常，可以附带使用的 API 类型和具体操作过程反馈。"
        ]
    },
    {
        version: "6.8.1",
        date: "2026-06-18",
        notes: [
            "**[重要测试] 修复聊天室串线与自动总结 Bug**",
            "尝试修复了退出聊天室时状态残留导致界面串线的问题，以及自动总结相关的异常。",
            "**[数据清理] 解决“幽灵角色”残留问题**",
            "优化了删除角色时的深层清理逻辑。对于已删除但仍在联系人列表中残留的“幽灵角色”，现在将会被彻底清理并屏蔽。",
            "————",
            "作者留言：本次更新属于测试性修复。如果在体验中发现任何问题或不妥之处，我会随时回退。欢迎大家及时反馈！"
        ]
    },
    {
        version: "6.8",
        date: "2026-06-08",
        notes: [
            "6.8更新（上）：",
            "1.优化存储",
            "2.优化收藏日记置顶的功能",
            "3.修复表情包掉格式的问题",
            "4.重构整个自动总结",
            "5.新增两个总结按钮",
            "6.新增结构化记忆",
            "7.新增向量记忆",
            "8.新增系统级通知在聊天详情页面也能收到通知的",
            "9.优化了本地字体的上传，方法来自1900老师",
            "10.新增单独保活",
            "11.新增给NOVEL生图新增自定义API地址和预设管理",
            "12.新增GPT生图（生图成功版）"
        ]
    },
    {
        version: "5.1",
        date: "2026-05-01",
        notes: [
            "5.1更新：",
            "依旧是除了写出来的更新还优化了其他地方的一些流程",
            "1.新增编辑消息可以插入语音和引用",
            "2.修复顶栏",
            "3.微调了一下时间感知，新增时间间隔也可以编辑了",
            "4.新增全局聊天背景更换和通话背景更换",
            "5.新增角色和用户动态时区",
            "6.新增角色可看见用户的收藏",
            "7.优化拉黑关于未处理的好友申请卡住问题和拉黑状态随“开启新档”和“清空聊天记录”重置",
            "8.新增提示词可以自定义，可以给每个角色配置不同的",
            "9.新增顶栏文件夹有未读消息会显示红点",
            "10.修复消息通知。",
            "11.新增系统级别通知，没有测试过，可能有BUG，IOS只有16.4+才支持",
            "12.优化世界书，可以拖动更改位置，可以搜索",
            "13.优化提示词世界书，增加权重和关键词，关键词就相当于酒馆的绿灯蓝灯，权重就相当于深度？",
            "14.新增思维链可以拖动",
            "15.新增天气API",
            "16.新增后台消息随机间隔"
        ]
    },
    {
        version: "4.26",
        date: "2026-04-26",
        notes: [
            "4.26更新：",
            "1.新增用动态户生日",
            "2.新增角色可以识别用户的表情包",
            "3.新增角色在发送的时候也可以识别表情包的样子",
            "4.回退之前的聊天模式，失忆应该好了吧！",
            "5.新增联网按钮，这样模型就可以自己上网去了，如果你要问我为什么不能直接用联网模型，因为我喜欢做点无厘头的HHH",
            "6.新增现在线下也可以更新状态栏了",
            "7.新增接入豆包语音，不过我没试过能不能用，有问题明天再修复吧",
            "8.新增群聊可以移除成员",
            "9.新增群聊双语可以选择生效",
            "",
            "优化了一些其他部分。太细了我不写了"
        ]
    },
    {
        version: "4.25",
        date: "2026-04-25",
        notes: [
            "4.25更新：",
            "1.修复识图BUG",
            "2.新增角色单人思维链",
            "3.修复线下失忆的BUG",
            "4.新增日记收藏会自动置顶的开关",
            "5.修复亲属卡问题，现在绝对不给用户扣款了！而且角色也能感知到扣款",
            "6.移动记忆存到到拓展，并且新增开新档",
            "7.新增可以手动添加日记，可以导入导出日记，可以搜索日记",
            "8.新增表情包分类菜单，可以新建/删除/重命名",
            "9.修复失忆的BUG",
            "10.修复双语和引用遮挡的BUG",
            "本来还有一些内容的，但是因为失忆暂时先端上来给大家尝尝，有问题再反馈哦",
            "主要是之前有些反馈我忘记了……我记忆力很差TUT。"
        ]
    },
    {
        version: "4.24",
        date: "2026-04-24",
        notes: [
            "4.24 更新：",
            "这是1900老师做的更新！1900我们喜欢你！",
            "新增： 聊天设置-关联世界书，新增线下选项，在节点系统进行线下时优先调用线下tag里绑定的世界书，若无绑定，则回退使用线上tag内绑定的世界书",
            "优化： 日记、查手机、论坛的输出格式要求从【纯json格式】改为→**【xml标签格式】**，对api质量要求降低了很多，如先前绑定了强调json格式防止掉格式的世界书，请做出相应调整更改",
            "提示词调整： 对于提示词做了优化，移动了聊天记录在提示词里的位置，新增了对于防句式重复的提示词",
            "关于claude模型：",
            "1.claude不要开思维链，模型不支持不要开",
            "2.已修复：400报错、日记总结、查手机、论坛格式报错"
        ]
    },
    {
        version: "4.9",
        date: "2026-04-12",
        notes: [
            "4.9更新：",
            "1.新增触感开关，默认开启",
            "2.新增日记可以全选",
            "3.适配 Markdown 格式的文字",
            "4.新增收藏删除可以全选或者按照角色删除",
            "5.优化角色高级清理",
            "6.修复角色语音下载为空的问题",
            "7.修复正则BUG问题",
            "8.修复转账偶发点不动的情况",
            "9.优化论坛大小号包括掉马的提示词",
            "10.优化退出后聊天丢失的情况",
            "11.修复跟随开场白导入导致白屏的BUG",
            "12.新增转发消息",
            "13.新增高级清理可以清除角色转账记录等",
            "14.新增导出角色卡，是专属章鱼机的角色卡"
        ]
    },
    {
        version: "3.18",
        date: "2026-03-18",
        notes: [
            "3.18更新：",
            "1.新增节点系统，可以线下、真心话、番外等等，所有人具体的去看1900DC的文字教程！",
            "2.修复新增CHAR消息后续报错的BUG",
            "3.新增下载语音TTS，在TTS开启情况下会出现在长按菜单里",
            "4.新增中途意外挂断通话的保护，会自动保存在通话记录并且总结",
            "5.新增10楼外仅发送摘要的数字变量自定义（1900提供想法）",
            "6.自定义输出消息格式时，勾选上第三方的话选项那条消息在被渲染的时候就以系统消息的样式显示，如没勾选会默认以char的气泡显示",
            "7.配置的导出导入文件（1900的想法）",
            "8.新增可以保存重说消息，可以切换",
            "9.新增可以单独ROLL生图",
            "10.新增夜间模式和顶栏电量和时间"
        ]
    },
    {
        version: "3.16",
        date: "2026-03-16",
        notes: [
            "3.16微量更新：",
            "1.优化教程区域的白兔岛、简约和底部匿名、公开许愿的适配，新增自定义CSS美化",
            "2.优化清空消息、头像识别系统位置",
            "3.优化情头库上传歪歪布局的BUG",
            "4.新增角色导入导出聊天记录",
            "5.修复增加消息一直是USER的BUG",
            "6.新增状态栏删除按钮重置位置的按钮，为了防止笨蛋小狗拖动出错！",
            "7.优化导入世界书格式，改成全部为一个条目了",
            "8.⭐受1900高人指点！！新增了一个跳过思考的开关，不知有效否⭐",
            "许愿和反馈都收到了！明天严肃修改新增"
        ]
    },
    {
        version: "3.15.1",
        date: "2026-03-15",
        notes: [
            "3.15微量更新：",
            "1.新增亲属卡删除，角色只能送一张亲属卡",
            "2.新增后台消息弹窗",
            "3.修复拉黑记忆一直持续记着，清空也没办法删除",
            "4.新增情头库上传功能",
            "5.修复状态栏文字修改后状态栏没有更新的BUG",
            "6.修复浏览器标题过长被挡住，大家觉得现在的布局看着舒服吗"
        ]
    },
    {
        version: "3.15",
        date: "2026-03-15",
        notes: [
            "3.15更新：",
            "内置了1900老师的输入框代码、萤火的uwu短屏代码，感谢两位女神的授权！",
            "内置了投稿/反馈的网页链接，是完全匿名的。",
            "1.新增论坛可以分享贴子给群聊，可以多选删除已有帖子",
            "2.新增小剧场可以调节字体，世界书可以多选移动到分类和多选启用和停用（豹豹老师改）",
            "3.新增免打扰时间段，这段时间应该不会有后台消息发来",
            "4.新增提醒事项，角色可以自行创建自己的代办事项，也可以在聊天过程中，帮用户创建代办事项。到点会自动提醒",
            "5.新增编辑可以新增消息，修复语音、视频不能自动播放的BUG",
            "6.新增偷看手机专属API",
            "7.新增头像系统，总之就是角色可以裁剪情头、自己更换头像，能发现用户头像的使用变化，比如说用户换头像会问一嘴。然后可以感知情头，生气了自己会换掉情头，或者用户换掉情头也会感知",
            "8.新增识图可以一次性上传多张图，修复用户头像刷新不及时的BUG",
            "9.新增删除状态栏按钮可以拖动",
            "10.新增拉黑系统，可以拉黑角色或者被角色拉黑，拉黑角色后仍可发言，但是角色不能回复，加回好友之前角色会记得拉黑后用户发的话，角色可以拒绝用户的申请",
            "11.新增浏览器可以点进去可以查看详情",
            "12.新增可以用角色手机给联系人发消息了，可以加联系人为好友，在聊天过程里面补充人设。需要现在偷看设置里面开启此开关",
            "13.新增角色可以查看并且控制用户手机，可以替用户发消息，可以替用户删除好友，可以随意开关设置里面的开关，并且在用户尝试关掉此权限的时候进行阻拦",
            "14.新增亲属卡，可以赠送亲属卡给角色，或者角色可以赠予亲属卡给你，可以调整亲属卡额度，冻结，收回，角色同样也可以调整给用户的亲属卡额度，冻结，收回。并且用户使用亲属卡，角色会有感知",
            "15.新增云备份可以大容量分片上传",
            "16.新增发送消息时可以有声音",
            "17.新增角色高级清理，可以直接清理聊天记录啥啥的",
            "18.新增多选收藏可以合并，可以在外面多选删除收藏"
        ]
    },
    {
        version: "3.7",
        date: "2026-03-07",
        notes: [
            "3.7重大更新：",
            "1.小剧场新增角色主动生成！新增导出功能，并且再度进行优化，感谢豹豹老师！",
            "2.感谢理芽给UWU接入了生图和视频生图！特别伟大！感谢感谢！现在UWU可以生图啦！！配上1900老师的视频UI特别特别美妙！！",
            "3.新增本地上传字体",
            "4.新增状态栏可以多选删除（不删除也会自动屏蔽的）",
            "5.TOKEN分布更加详细！",
            "6.删掉音乐自动检测有效的BUG，修复来电提示音的BUG",
            "7.新增论坛可以创建用户小号，角色不会知道，但是！如果和大号太像了，会掉马！",
            "8.新增论坛可以私信评论区的人，可以回复评论区的人"
        ]
    },
    {
        version: "3.5",
        date: "2026-03-05",
        notes: [
            "3.5微量更新：",
            "1.修复了群聊记忆互通的BUG（豹豹老师修）",
            "2.加了小剧场分类导入导出和预设保存可选择同步保存人设世界书等等（豹豹老师加）",
            "3.修复TTS开关问题，修复TTS国际版问题",
            "4.删掉了自动揭露",
            "5.新增了真实摄像头，视频通话可以看到真实的你的样子（没有人许愿这个，但是！我想做就做了！）"
        ]
    },
    {
        version: "3.4",
        date: "2026-03-04",
        notes: [
            "3.4微量更新：（临时起意想要更新，所以没有什么）",
            "感谢豹豹老师再再再再次优化小剧场，现在小剧场可以HTML和独立API了！包括群聊问题、转账问题也感谢豹豹老师修复了！",
            "————",
            "1.稍微优化了一点点音乐界面吧，然后可以在线搜索听着玩，单独一个APP是准备后面和角色一起听分开，想做个听歌匹配陌生人",
            "2.新增图标名字自定义，导出屏幕自定义的时候也可以导出偷看里面的APP了",
            "3.修复冗余数据清除错误问题，修复记忆存档删除后，导入备份再次出现的问题",
            "4.新增正则功能，主要是用来过滤八股的",
            "5.新增删除消息的同时删除对应的状态栏和思维链",
            "6.修复超过1000条的回顶全部点不动的BUG",
            "7.新增时间戳样式，新增输入框增高开关",
            "8.优化了一点点日记保存按钮样式，更加明显方便点击"
        ]
    },
    {
        version: "3.2",
        date: "2026-03-02",
        notes: [
            "感谢豹豹老师再次优化小剧场",
            "1.修复论坛私聊串来串去的问题",
            "2.修复论坛角色伪装失败！这次绝对很成功！修复角色头像明显、角色不适用填写好的昵称",
            "3.互通了论坛大小号的记忆。修复论坛刷新不适用专属论坛API的BUG",
            "4.修复用户商城赠送也会被算进钱包的BUG",
            "5.修复记忆转跳弄错CHAR的问题",
            "6.新增语音语速设置",
            "7.新增偷看部分APP可以自定义生成条数",
            "其他更新在做了在做了"
        ]
    },
    {
        version: "3.1",
        date: "2026-03-01",
        notes: [
            "**着重感谢：豹豹女神再次优化小剧场和冰镇草莓老师提供的全屏思路**",
            "————",
            "1.新增暂停调用按钮",
            "2.新增聊天背景重置，全局导出美化新增APP图标，我昨天脑子糊涂了忘记了",
            "3.修复接入语音后，文字消息输出太快了，就导致一句话没读完就读下一句的BUG",
            "4.新增搜索出来的聊天记录可以回顶了，然后聊天设置里面也新增了回底回顶。",
            "5.修复TTS把用户声音和角色声音同步了，并且新增可以配置用户的声音",
            "6.修复TTS无法暂停的BUG，新增退出聊天页面即可暂停，并且二次点击也可以暂停",
            "7.新增直接拍照。",
            "8.新增清理本地图片，新增相册一键清空",
            "9.新增论坛功能，新增角色小号，喜欢玩私信的小心了，角色可能会用小号接近你。",
            "10.新增功能，角色可以自主更换导入的CSS主题",
            "11.新增功能，查手机会被角色知晓（需要先设置里面打开）",
            "12.改掉了双语模式还读翻译的BUG",
            "一些功能没做，一个是因为我一个人测试不过来，直接放上来又太冒险，所以还在酝酿中。",
            "还有一些新APP在慢慢磨前端网页，所以也还在酝酿"
        ]
    },
    {
        version: "2.28",
        date: "2026-02-28",
        notes: [
            "首先前排感谢两位女神！",
            "感谢豹豹/放假老师提供的功能，以下是豹豹/放假老师提供的更新日志：",
            "① 生成后的小剧场内容现已支持分类保存、收藏和编辑，并可分享给任意 char。",
            "②支持将角色所在群聊的记忆与私聊进行互通，并可自定义聊天条数及总结范围。",
            "群聊总结数量默认为 0：表示 char 会选择记忆该群聊的全部收藏总结。",
            "若修改为 1：表示 char 仅选择记忆最近 1 条群聊中的收藏总结（数字可按需调整）。",
            "‼️ 当 char 在多个群聊内时，如需为角色选择不同的群聊记忆，需要先在私聊界面开启“所在群聊记忆互通”按钮，并获取一次回复后，才可以进行群聊的选择。",
            "🆕群聊中的角色现已支持选择记忆私聊内容，记忆方式与角色记忆群聊内容的方式一致，实现双向记忆互通。",
            "————",
            "其次感谢1900老师提供的偷看手机的同比例图标素材！我抠图水平太烂了！",
            "————",
            "以下是所有更新内容：",
            "1.修复在没有开启TTS的情况下一直提示TTS未开启，新增可以清除选择过的内置音色",
            "2.修改了一下论坛私信逻辑，之前是只有用户发的贴子，现在用户在论坛里面评论也会引起某些NPC注意来私信你",
            "3.新增论坛私信逻辑，可以在论坛里面添加私信的人为好友，并且在聊天中一步步补齐这个私信NPC的人设！为了省API可以在API设置里配专门的补齐人设的副API！也可以手动补齐！",
            "4.新增可以分享论坛评论了。",
            "5.修复全局世界书没有自动关联的BUG，新增世界书分类可以删除、条目可以选择是否启用",
            "6.新增小组将和壁纸的自定义区域，可以导入导出方案。",
            "7.新增发送定位，角色也可以发送",
            "8.修复音乐播放和消息提示音冲突的问题。",
            "9.新增来电提示音，需自己上传音频",
            "10.修复存钱罐存了退回转账的BUG",
            "11.新增小剧场，感谢豹豹女神",
            "12.新增群聊私聊互通，再次感谢豹豹女神。",
            "13.商城和存钱罐同步。现在给角色代付，自己要买东西，角色给自己代付都会同步到对应的钱包。",
            "14.修复TTS粤语映射错误的BUG",
            "15.新增导入角色卡有开场白，左右滑动可以切换。",
            "16.新增世界书可以导入DOCX、TXT、JSON格式。",
            "17.新增表情包智能匹配。",
            "18.修复论坛专属API保存失效的BUG",
            "一些小的改动就不说了"
        ]
    },
    {
        version: "1.8",
        date: "2026-02-23",
        notes: [
            "UwU小章鱼0223改版 对应版本1.8",
            "源代码来源：EE、1900、莫由（论坛功能by莫由），发布前已告知1900",
            "————",
            "主要改动内容（其实也没有改动什么）：",
            "1.新增导入DOCX、TXT、ZIP角色，新增各种地方可以导入DOCX、TXT，表情包DOCX和TXT解析的比较宽泛，目前资源区的应该都能导入（？）",
            "2.新增语音TTS",
            "3.新增自动总结，TOKEN分布",
            "4.新增记忆库存档",
            "5.调整了一下搜索界面的CSS样式。",
            "6.新增收藏功能，可以写下自己收藏时候的感想，角色也可以自主收藏你的。需要自主开启",
            "7.新增查手机小号的帖子可以点进去看评论",
            "8.修改了当前的论坛逻辑。新增私信功能（可以私信别人或者收到别人私信）、评论、点赞、收藏、自己发帖。可以自定义配置论坛的API",
            "9.新增两个副API用于总结、后台活动",
            "10.新增全局世界书",
            "11.新增查手机的时光想说，大概是抒情风，就是遇到各种不同年纪的USER的时候CHAR怎么想的",
            "12.新增查手机的角色钱包。有两种UI界面，点击右上角太阳可以切换。",
            "13.新增主角自己的钱包。",
            "然后导出应该已经同步了，就这样。",
            "本来还想做小游戏的，燃尽了，下次吧",
            "还做了一些其他的调整，具体小优化比较细，我不写出来了。"
        ]
    },
    {
        version: "1.8.5",
        date: "2026-02-18",
        notes: [
            "聊天功能新增：视频通话/语音通话，用户打电话入口在功能面板里，char主动打电话需在聊天设置里打开开关",
            "思维链页面新增：通话专属cot设置，可开可不开，已内置默认思维链，支持自定义",
            "**操作指南：所有人！去dc小手机主频道看使用教程视频！**",
            "—————————————",
            "通话结束后自动总结，仅总结内容进入上下文。",
            "如总结失败，可以在通话记录里找到那次记录，点开，重新总结。如果频繁失败，可以复制通话记录里的全部内容找其他ai给你总结。",
            "如何查看总结内容？：进入调试模式，点击那个“视频通话结束”的系统消息，可以看到总结内容",
        ]
    },
    {
        version: "1.8.4",
        date: "2026-02-14",
        notes: [
            "新增卡COT思维链，原理同酒馆，部分预设条目改自吱吱的过境预设，卡cot方法原理来自KKM的预设教程，非常感谢！",
            "思维链目前应该仅对**Open AI**的**Gemini**模型生效，其他模型暂未测试。",
            "位置：404-Menu界面，默认为关闭状态，按需开启，内置默认思维链，支持自定义思维链，支持自定义思维链导入导出。",
            "思维链功能可能会影响AI的回复风格，但开启后在回复条数的自然程度和各特殊消息的使用上有明显进步，请根据实际情况选择开启。",
        ]
    },
    {
        version: "1.8.3",
        date: "2026-01-27",
        notes: [
            "1.日记功能升级！新增摘要总结风格，支持自定义风格。",
            "现在生成日记会自动带入聊天室背景，无需重复绑定。",
            "优化了日记生成的提示词，摘要风格更客观、时间线更清晰。",
            "智能迁移：旧版日记关联已自动优化，去除了重复的背景设定。",
            "合并精简：新增多选日记进行合并，将多篇日记整合成一篇连贯、精简的“回忆录”，自动梳理时间线。",
            "参考过往：生成新日记时，可选择**参考已收藏的日记**。AI 会读取您收藏的重点回忆，确保新内容的连贯性，避免重复记录。",
            "—————————————",
            "2. 全新商城系统",
            "自定义分类：支持自定义分类名称和提示词。商城首页点击右上角 “＋”",
            "自选开关：如果不喜欢商城干扰聊天，可以在设置中关闭此功能。（仅关闭char不主动给你买东西和代付，你仍然可以单方面使用商城）",
            "—————————————",
            "3. 偷看界面 x 商城联动",
            "在偷看模式下，进入 “购物车”应用，点击底部的“结算”按钮，可以直接帮Ta买单。在偷看界面结算后，系统会自动跳转回聊天界面，并发送一条 “我为Ta清空了购物车” 的订单消息。",
            "4. 全局css救援",
            "任何界面里快速点5下，呼出救援面板一键清空全局css框内容"
        ]
    },
    {
        version: "1.8.2",
        date: "2025-01-24",
        notes: [
            "修了一点bug，提示音现在正常可以使用了",
            "解除了自定义css区域的限制，现在可以用全局变量之类的了，但是仍旧只生效于聊天室内！",
            "过往的美化有少量类名前面没加#chat-room-screen的可能有偏移！比如顶栏底栏的一些小地方，给美化老师们跪下了TT",
            "修了一些bug，做了提示音，【开始生成】是点让ai回复的那个按钮触发的音效，收到回复是发消息给你触发的音效",
            "做了朋友的一个纯点菜功能，选定指定片段截图，但是有bug截取不到气泡啥的只有纯文字和背景",
            "那个测试直播间别点，纯样板间很丑陋！太丑了做不下去了嗯！",
            "—————————分割线————————",
            "刚接触章鱼机的有使用相关问题先看主屏幕→教程→更新日志，全都翻一遍！",
            "其次再看聊天列表底部导航栏→通话图标，点击之后有详细的新版本更新说明，全都翻一遍！",
            "如果出现报错日志，自己看不懂就复制日志内容发给ai问",
            "还有问题就去尾巴镇→ee小手机区→标注搜索：小章鱼UwU问题自助",
            "关于状态栏是肯定要和ai肘击的，很难一步到位，状态栏不是必需品，会影响ai的回复质量",
            "以上这些能囊括90%的解决方法，尽量不要就基础问题消耗无偿答疑老师们的热情，亲亲你们！",
        ]
    },
    {
        version: "1.8.0",
        date: "2025-01-15",
        notes: [
            "先别点【我知道了】，看完看完看完",
            "本次更新的群成员私聊和Ta相册皆为【测试中】功能，不知道效果如何，均做了可选开关，不开也不影响正常玩",
            "🔍 搜索页: 快速查找聊天记录，支持关键词高亮。",
            "🖼️ TA 相册: 在聊天设置管理角色的专属相册，在聊天设置里开启此开关后，聊天时角色可直接发送你已经上传的图片（最好使用url）。",
            "📢 群公告: 群聊设置中新增公告功能，重要信息置顶显示。",
            "🤫 群内私聊: 群聊中支持成员间发起私聊，双击群聊标题可查看，八卦吐槽更方便。",
            "📝 群聊总结: 智能总结群聊记录，自动关联当前群聊世界书，内置提示词。",
            "📒 token：角色资料卡处（联系人界面点击角色头像），粗略统计角色当前聊天室的token，并不完全准确仅作参考！",
            "—————————分割线————————",
            "刚接触章鱼机的有使用相关问题先看主屏幕→教程→更新日志，全都翻一遍！",
            "其次再看聊天列表底部导航栏→通话图标，点击之后有详细的新版本更新说明，全都翻一遍！",
            "如果出现报错日志，自己看不懂就复制日志内容发给ai问",
            "还有问题就去尾巴镇→ee小手机区→标注搜索：小章鱼UwU问题自助",
            "关于状态栏是肯定要和ai肘击的，很难一步到位，状态栏不是必需品，会影响ai的回复质量",
            "以上这些能囊括90%的解决方法，尽量不要就基础问题消耗无偿答疑老师们的热情，亲亲你们！",
        ]
    },
    {
        version: "1.7.2",
        date: "2025-01-15",
        notes: [
            "先别点【我知道了】，看完看完看完",
            "刚接触章鱼机的有使用相关问题先看主屏幕→教程→更新日志，全都翻一遍！",
            "其次再看聊天列表底部导航栏→通话图标，点击之后有详细的新版本更新说明，全都翻一遍！",
            "如果出现报错日志，自己看不懂就复制日志内容发给ai问",
            "还有问题就去尾巴镇→ee小手机区→标注搜索：小章鱼UwU问题自助",
            "关于状态栏是肯定要和ai肘击的，很难一步到位，状态栏不是必需品，会影响ai的回复质量",
            "以上这些能囊括90%的解决方法，尽量不要就基础问题消耗无偿答疑老师们的热情，亲亲你们！",
        ]
    },
    {
        version: "1.6.0",
        date: "2025-01-04",
        notes: [
            "本次更新：更迭了表情包的机制，过往的机制因比较占token弃用，所以以前聊天记录的不再渲染。",
            "批量导入表情包时使用英文/中文的冒号都可以。",
            "现在的表情包如何使用？批量导入时填写分组名称，一定要填！未分类的表情包不能被char使用（包括你以前的表情包都属于未分类）；然后在侧边栏给char选择他可以使用的表情包分组即可。",
            "以前的表情包统一归类到未分类里，想给char使用时一定要多选时→转移分组→自己分一下类。",
            "偷看手机的数据现在不会退出即清空了，想生成下一次之前点击右上角的删除一键清空即可。",
            "有任何报错请首先在dc小手机区标注内搜索uwu，有自助答疑清单，不要就基础问题消耗无偿答疑老师们的热情，亲亲你们！",
            "过往更新说明 及 功能使用说明 重复观看指路→主屏幕的教程app→更新说明！新手宝宝一定要看哦。",
        ]
    },
    {
        version: "1.5.0",
        date: "2025-12-17",
        notes: [
            "本次更新：应该大大降低了日记生成出错的概率，感谢匿名小宝自发修改测试并提供的修复代码！",
            "匿名小宝捎来讯息：感谢所有一直为爱发电、无私分享代码的开发小手机的老师们！",
            "在此私心也想对所有为爱发电做UwU美化以及答疑解惑的老师们表示感谢！鞠躬——！",
        ]
    },
    {
version: "1.4.0",
date: "2025-12-12",
notes: [
    "本次更新：GitHub云端备份功能上线！指路→主屏幕的【教程】app→划到页面最底部即可看到。（UI从其他地方搬的，懒得做美化了！将就用吧对不起！）",
    "主要功能：一键上传/恢复最新备份。配置好后，备份数据直接存到你自己的GitHub私人仓库里，恢复即从你的仓库中自动选取时间戳最新的备份文件导入恢复。",
    "配置太难不会弄？别慌！点击配置栏旁边的【蓝色小问号图标】，里面内置了手把手的保姆级教程。不要被英文吓到，跟着步骤点几下，配置一次，终身受益。",
    "测试中功能，不一定有用：配置完成后，可根据自身需要开启【自动备份开关】！设置好频率（比如每24小时），以后只要你打开这个网页，它就会在后台悄悄帮你把存档上传到云端，再也不用担心忘记备份了。",
    "特别提醒：为了你的数据安全，在GitHub账户中获取的 Token (以 ghp_ 开头的那一串) 和仓库名称请务必自己保存好，不要发给别人哦！",
    "过往更新说明重复观看指路→主屏幕的教程app→更新说明！",
    ]
    },
    {
        version: "1.3.0",
        date: "2025-11-11",
        notes: [
            "务必仔细观看！重复观看指路→主屏幕的教程app→更新说明！",
            "新增：双语模式，位于聊天界面的侧边栏内，当char为外国人而你想要更沉浸式的对话时，可按需开启，开启后会将“外文中文）”的消息识别成双语消息气泡，注意！中文翻译必须在括号内，点击气泡后展开翻译。",
            "新增：流式传输开关，位于api设置界面，开跟不开不知道有什么区别，总之做了嗯嗯。没改之前默认是流式传输，如果非流出不来就开流式，流式出不来就关流式，都出不来我也没招了！",
            "补充教学：发现有些宝宝还有地方不太清楚怎么使用，补充一下",
            "2. 回忆日记：生成日记后，需点亮该篇日记右上角的☆按钮收藏，收藏后该篇日记才会作为char的回忆加入聊天上下文中",
            "3. 日记使用拓展方法：日记内容可编辑，当日记篇数过多/char被日记内的主观形容影响性格较大时，可以将你需要保留的日记内容复制给某个ai（豆包、deepseek、哈吉米都行）进行大总结，指令参考：以全客观的、不参杂任何主观情绪，以第三人称视角按照时间顺序总结发生过的事件和关键语句。然后将返回的总结塞进日记收藏加入上下文即可。",
        ]
    },
    {
        version: "1.2.0",
        date: "2025-10-15",
        notes: [
            "新增：世界书批量删除功能，长按条目即可进入多选删除模式，支持分类全选。",
        ]
    },
    {
        version: "1.1.0",
        date: "2025-10-13",
        notes: [
            "新增：番茄钟，可以创建专注任务并绑定char和自己的人设预设（仅可从预设中选择），在列表中左滑删除任务。专注期间想摸鱼了可以戳一戳头像，ta会对你做出回复。每个专注界面的设置键可以自定义鼓励频率和限制自己戳一戳的次数，超过次数则ta不会再理你，请补药偷懒，努力专注吧！",
            "新增：两个桌面小组件，现所有小组件都可以通过点击来自定义图片和文字",
        ]
    },
    // ... 其他更新日志可以在 tutorial.js 中处理，这里保留最新的即可，或者全部保留
];

// 全局变量
var db = {
    characters: [],
    groups: [],
    bilingualSettings: { display: 'click', scopes: { moments: true, peek: true, journal: true, forum: true, battery: true, pomodoro: true, theater: true, friendRequest: true } },
    bilingualTranslations: {},
    apiSettings: {},
    summaryApiSettings: {},
    backgroundApiSettings: {},
    supplementPersonaApiSettings: {},
    peekApiSettings: {},
    vectorApiSettings: {},
    apiNodes: [],
    apiNodeRoutes: {},
    wallpaper: 'https://i.postimg.cc/W4Z9R9x4/ins-1.jpg',
    globalChatWallpaper: '',
    globalCallWallpaper: '',
    myStickers: [],
    homeScreenMode: 'night',
    worldBooks: [],
    fontUrl: '',
    localFontName: '',
    customIcons: {},
    customAppNames: {},
    apiPresets: [],
    summaryApiPresets: [],
    backgroundApiPresets: [],
    supplementPersonaApiPresets: [],
    peekApiPresets: [],
    vectorApiPresets: [],
    bubbleCssPresets: [],
    chatAppearancePresets: [],
    myPersonaPresets: [],
    fontPresets: [],
    forumPosts: [],
    forumAccountStates: {},
    forumRelationships: {},
    forumKnowledge: [],
    forumSocialEdges: [],
    forumStoryThreads: [],
    forumEvents: [],
    forumNotifications: [],
    forumDrafts: [],
    forumSchemaVersion: 2,
    globalCss: '',
    globalCssPresets: [],
    homeSignature: '编辑个性签名...',
    forumBindings: {
        worldBookIds: [],
        charIds: [],
        userPersonaIds: []
    },
    pomodoroRecords: [],
    pomodoroActiveSession: null,
    pomodoroTasks: [],
    pomodoroSettings: {
        boundCharId: null,
        userPersona: '',
        focusBackground: '',
        taskCardBackground: '',
        encouragementMinutes: 25,
        pokeLimit: 5,
        globalWorldBookIds: []
    },
    insWidgetSettings: {
        avatar1: 'https://i.postimg.cc/Y96LPskq/o-o-2.jpg',
        bubble1: 'love u.',
        avatar2: 'https://i.postimg.cc/GtbTnxhP/o-o-1.jpg',
        bubble2: 'miss u.'
    },
    chatFolders: [],
    moments: null,
    fontSizeScale: 1.0,
    savedKeyboardHeight: null,
    activePersonaId: null,
    moreProfileCardBg: 'https://i.postimg.cc/XvFDdTKY/Smart-Select-20251013-023208.jpg',
    statusBarPresets: [],
    regexFilterPresets: [],
    themeSettings: {
        global: {
            iconColor: '#000000',
            textColor: '#2a3032',
            titleColor: '#000000',
            backgroundColor: '#ffffff'
        },
        wallpapers: {
            contacts: '',
            chats: '',
            more: ''
        },
        bottomNav: {
            iconColor: '#999999',
            activeIconColor: '#2a3032',
            items: [
                { defaultIcon: '', activeIcon: '' },
                { defaultIcon: '', activeIcon: '' },
                { defaultIcon: '', activeIcon: '' },
                { defaultIcon: '', activeIcon: '' }
            ]
        },
        chatScreen: {
            bottomBarColor: '#ffffff',
            iconColor: '#000000',
            folderPillColor: '#ffffff'
        }
    },
    themePresets: [],
    globalSendSound: '',
    globalReceiveSound: '',
    globalMessageSentSound: '',
    globalIncomingCallSound: '',
    multiMsgSoundEnabled: false,
    hapticEnabled: true,  // 触感反馈开关，默认开启
    soundPresets: [],
    galleryPresets: [],
    iconPresets: [],
    cotSettings: {
        enabled: false,
        activePresetId: 'default'
    },
    cotPresets: JSON.parse(JSON.stringify(DEFAULT_COT_PRESETS)),
    archives: [],
    favorites: [],  // 消息收藏：{ id, messageId, chatId, chatType, chatName, content, timestamp, favoriteTime, note, sender }
    phoneControlRecycleBin: [],  // 角色掌控模式：被角色“删除”的角色移入回收站，可恢复
    memoryTableTemplates: [],
    vectorMemoryTemplates: []
};

var currentChatId = null;
var currentChatType = null;
var isGenerating = false;
var currentReplyAbortController = null; // 用于「暂停调用」中止当前 AI 请求（单聊/群聊共用）
var longPressTimer = null;
var isInMultiSelectMode = false;
var editingMessageId = null;
var currentPage = 1;
var currentTransferMessageId = null;
var currentEditingWorldBookId = null;
var currentStickerActionTarget = null;
var currentJournalDetailId = null;
var currentQuoteInfo = null;
var isDebugMode = false;
var currentFolderId = 'all';
var currentFolderActionTarget = null;
var currentGroupAction = {type: null, recipients: []};
var isRawEditMode = false;
var currentPomodoroTask = null;
var pomodoroInterval = null;
var pomodoroRemainingSeconds = 0;
var pomodoroCurrentSessionSeconds = 0;
var isPomodoroPaused = true;
var pomodoroPokeCount = 0;
var pomodoroIsInterrupted = false;
var currentPomodoroSettingsContext = null;
var pomodoroSessionHistory = [];
var isStickerManageMode = false;
var selectedStickerIds = new Set();
var isWorldBookMultiSelectMode = false;
var selectedWorldBookIds = new Set();
var generatingPeekApps = new Set();
var selectedMessageIds = new Set();
var currentStickerCategory = 'recent';
const MESSAGES_PER_PAGE = 50;


// Dexie 数据库初始化
var dexieDB; // 声明全局变量，但不初始化

